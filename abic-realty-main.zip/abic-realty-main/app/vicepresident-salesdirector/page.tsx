import ContactCard from "../../components/contact-card"

export default function VicePresidentSalesDirectorPage() {
  return <ContactCard />
}
